import os


__VERSION__ = "0.0.1"

ASSAY_LIST = [
    "build",
    # "init",
    # "run",
]

ROOT_PATH = os.path.dirname(__file__)
SOFTWARE_NAME = "scAfterSalesPipline"
